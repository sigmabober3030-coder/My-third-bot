#!/usr/bin/env python3
"""Telegram-бот для Bonsai (llama-server). Только стандартная библиотека Python, ~20 МБ памяти.

Как расширяется контекст при маленьком окне:
 - в запрос идут: системный промпт + заметки (/remember) + краткое содержание старого + последние реплики
 - когда история не влезает, старая половина откусывается ОДНИМ куском (префикс запроса меняется редко,
   значит llama-server берёт его из кэша и обрабатывает только новую реплику)
 - откушенное сжимается моделью в краткое содержание, когда бот простаивает
"""
import json
import os
import queue
import re
import threading
import time
import urllib.request
from pathlib import Path

TOKEN = os.environ.get("TG_TOKEN", "")
LLM = os.environ.get("LLM_URL", "http://127.0.0.1:8910/v1/chat/completions")
CTX = int(os.environ.get("CTX", "8192"))                  # должен совпадать с контекстом сервера
ALLOWED = {int(x) for x in os.environ.get("ALLOWED_IDS", "").replace(" ", "").split(",") if x}
SYSTEM = os.environ.get("SYSTEM", "Ты полезный ассистент в Telegram. Отвечай по-русски, коротко и по делу.")
REPLY = int(os.environ.get("REPLY_TOKENS", "500"))        # максимум токенов ответа
THINK = int(os.environ.get("THINK_TOKENS", "1500"))       # то же, когда включены размышления
STATE = Path(os.environ.get("STATE_FILE", "state.json"))
API = f"https://api.telegram.org/bot{TOKEN}/"

users, jobs, waiting = {}, queue.Queue(), {}
stats = {"gen": None, "prompt": None}
HELP = ("Команды:\n/reset: очистить диалог\n/think: размышления вкл/выкл (очень медленно)\n"
        "/remember текст: запомнить навсегда\n/memory: что запомнено\n/forget: стереть заметки\n/stats: скорость и контекст")


def est(s):
    return int(len(s) / 2.2) + 4


def load():
    if STATE.exists():
        users.update(json.loads(STATE.read_text(encoding="utf-8")))


def save():
    tmp = STATE.with_suffix(".tmp")
    tmp.write_text(json.dumps(users, ensure_ascii=False), encoding="utf-8")
    os.replace(tmp, STATE)


def U(uid):
    return users.setdefault(str(uid), {"hist": [], "summary": "", "mem": [], "think": False, "pending": []})


def tg(method, _t=30, **p):
    req = urllib.request.Request(API + method, json.dumps(p).encode(), {"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=_t) as r:
            return json.load(r)
    except Exception as e:
        print("telegram:", method, e)
        return None


def send(chat, text):
    r = tg("sendMessage", chat_id=chat, text=text[:4000])
    return r["result"]["message_id"] if r and r.get("ok") else None


def edit(chat, mid, text):
    if mid:
        tg("editMessageText", chat_id=chat, message_id=mid, text=text[:4000] or "…")


def system_text(u):
    s = SYSTEM
    if u["mem"]:
        s += "\n\nЗаметки о пользователе:\n- " + "\n- ".join(u["mem"])
    if u["summary"]:
        s += "\n\nКраткое содержание прошлого разговора:\n" + u["summary"]
    return s


def fit(u, think):
    """Собирает сообщения так, чтобы влезть в контекст; старое откусывается крупным куском."""
    sys_t = system_text(u)
    budget = CTX - est(sys_t) - (THINK if think else REPLY) - 64

    def total():
        return sum(est(m["content"]) + 6 for m in u["hist"])
    while total() > budget and len(u["hist"]) > 2:
        n = min(max(2, (len(u["hist"]) // 4) * 2), len(u["hist"]) - 2)
        u["pending"] += u["hist"][:n]
        u["hist"] = u["hist"][n:]
    if total() > budget:  # одно очень длинное сообщение
        u["hist"][-1]["content"] = u["hist"][-1]["content"][-int(budget * 2):]
    return [{"role": "system", "content": sys_t}] + u["hist"]


def llm_stream(msgs, think, max_tokens):
    body = {"model": "bonsai", "messages": msgs, "stream": True, "max_tokens": max_tokens, "temperature": 0.7,
            "cache_prompt": True, "chat_template_kwargs": {"enable_thinking": think}}
    req = urllib.request.Request(LLM, json.dumps(body).encode(), {"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=3600) as r:
        for line in r:
            line = line.decode("utf-8", "replace").strip()
            if not line.startswith("data:"):
                continue
            d = line[5:].strip()
            if d == "[DONE]":
                break
            j = json.loads(d)
            if j.get("timings"):
                stats["gen"] = j["timings"].get("predicted_per_second") or stats["gen"]
                stats["prompt"] = j["timings"].get("prompt_per_second") or stats["prompt"]
            ch = (j.get("choices") or [{}])[0].get("delta") or {}
            if ch.get("reasoning_content"):
                yield "think", ch["reasoning_content"]
            if ch.get("content"):
                yield "text", ch["content"]


def strip_think(s):
    return re.sub(r"<think>.*?(</think>|$)", "", s, flags=re.S).strip()


def answer(uid, chat, text):
    u = U(uid)
    think = u["think"]
    u["hist"].append({"role": "user", "content": text})
    msgs = fit(u, think)
    mid = send(chat, "💭 думаю…" if think else "⏳ …")
    tg("sendChatAction", chat_id=chat, action="typing")
    out, thought, last = "", 0, time.time()
    try:
        for kind, piece in llm_stream(msgs, think, THINK if think else REPLY):
            if kind == "think":
                thought += len(piece)
            else:
                out += piece
            if time.time() - last > 4:
                shown = strip_think(out)
                edit(chat, mid, (shown[-3800:] + " ▌") if shown else f"💭 думаю… (≈{thought // 3} ток.)")
                last = time.time()
    except Exception as e:
        u["hist"].pop()
        save()
        edit(chat, mid, f"⚠️ Ошибка модели: {e}")
        return
    final = strip_think(out) or "(пустой ответ)"
    u["hist"].append({"role": "assistant", "content": final})
    save()
    parts = [final[i:i + 4000] for i in range(0, len(final), 4000)]
    edit(chat, mid, parts[0])
    for p in parts[1:]:
        send(chat, p)


def summarize(key):
    u = U(key)
    old = u["pending"]
    text = "\n".join(("Пользователь: " if m["role"] == "user" else "Бот: ") + m["content"] for m in old)
    prompt = [{"role": "system", "content": "Ты сжимаешь историю чата. Верни ТОЛЬКО краткое содержание (до 120 слов) "
                                            "на русском: важные факты, договорённости, имена, числа."},
              {"role": "user", "content": (("Прежнее содержание:\n" + u["summary"] + "\n\n") if u["summary"] else "")
               + "Новые сообщения:\n" + text[-6000:]}]
    out = strip_think("".join(t for k, t in llm_stream(prompt, False, 250) if k == "text"))
    if out:
        u["summary"], u["pending"] = out[:1200], []
        save()


def worker():
    while True:
        try:
            uid, chat, text = jobs.get(timeout=20)
        except queue.Empty:  # бот простаивает: можно сжать накопившееся старое
            for k, u in list(users.items()):
                if sum(est(m["content"]) for m in u["pending"]) >= 500:
                    try:
                        summarize(k)
                    except Exception as e:
                        print("summary:", e)
            continue
        try:
            answer(uid, chat, text)
        finally:
            waiting[uid] = max(0, waiting.get(uid, 1) - 1)


def command(uid, chat, text):
    u = U(uid)
    cmd, _, arg = text.partition(" ")
    cmd = cmd.split("@")[0].lower()
    if cmd in ("/start", "/help"):
        send(chat, HELP)
    elif cmd == "/reset":
        u.update(hist=[], summary="", pending=[])
        save()
        send(chat, "Диалог очищен. Заметки остались (/memory).")
    elif cmd == "/think":
        u["think"] = not u["think"]
        save()
        send(chat, "Размышления: " + ("ВКЛ (ответы идут минутами)" if u["think"] else "выкл"))
    elif cmd == "/remember":
        if arg.strip():
            u["mem"] = (u["mem"] + [arg.strip()[:300]])[-20:]
            save()
            send(chat, "Запомнил.")
        else:
            send(chat, "Напиши после команды, что запомнить.")
    elif cmd == "/memory":
        send(chat, ("Заметки:\n- " + "\n- ".join(u["mem"])) if u["mem"] else "Заметок нет.")
    elif cmd == "/forget":
        u["mem"] = []
        save()
        send(chat, "Заметки стёрты.")
    elif cmd == "/stats":
        used = sum(est(m["content"]) + 6 for m in u["hist"])
        send(chat, f"Контекст: {CTX} ток.\nВ истории: ≈{used} ток., сжатое резюме: {'есть' if u['summary'] else 'нет'}, "
                   f"ждёт сжатия: {len(u['pending'])} реплик\nОчередь: {jobs.qsize()}\n"
                   f"Скорость: ответ {stats['gen'] or '?'} ток/с, разбор запроса {stats['prompt'] or '?'} ток/с")
    else:
        return False
    return True


def main():
    if not TOKEN or not ALLOWED:
        raise SystemExit("Задай TG_TOKEN и ALLOWED_IDS (твой Telegram ID) в .env")
    load()
    threading.Thread(target=worker, daemon=True).start()
    offset = 0
    print("Бот запущен, контекст", CTX)
    while True:
        r = tg("getUpdates", _t=70, offset=offset, timeout=50, allowed_updates=["message"])
        if not r or not r.get("ok"):
            time.sleep(5)
            continue
        for up in r["result"]:
            offset = up["update_id"] + 1
            m = up.get("message") or {}
            text, uid, chat = m.get("text"), (m.get("from") or {}).get("id"), (m.get("chat") or {}).get("id")
            if not text or not uid:
                continue
            if uid not in ALLOWED:
                send(chat, f"Нет доступа. Твой ID: {uid}")
                continue
            if text.startswith("/") and command(uid, chat, text):
                continue
            if waiting.get(uid, 0) >= 2:
                send(chat, "Подожди: предыдущие запросы ещё в работе.")
                continue
            waiting[uid] = waiting.get(uid, 0) + 1
            if jobs.qsize() >= 1:
                send(chat, f"В очереди: {jobs.qsize() + 1}")
            jobs.put((uid, chat, text))


if __name__ == "__main__":
    main()
