#!/usr/bin/env bash
# Сервер Bonsai, настроенный на минимум памяти.  ./start_llm.sh [контекст]   (по умолчанию 8192)
cd "${BONSAI_DIR:-$HOME/Bonsai-demo}" || { echo "Нет папки Bonsai-demo (задай BONSAI_DIR=путь)"; exit 1; }
export BONSAI_CTX="${1:-8192}" BONSAI_KV4=1
# --parallel 1: весь контекст достаётся одному запросу (иначе он делится на слоты)
exec ./scripts/start_llama_server.sh --alias bonsai --host 127.0.0.1 --port 8910 --parallel 1
